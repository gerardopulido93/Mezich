function [ rho_air ] = AirDensity( h )
    [ T,P ] = Atm_T_P( h );
    rho_air = P/(0.2869*(T+237.1));
end

