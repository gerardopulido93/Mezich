function [ W_Air ] = AirWeight( rho_air,R )
    W_Air = (4*pi*rho_air*R^3)/3; 
end

