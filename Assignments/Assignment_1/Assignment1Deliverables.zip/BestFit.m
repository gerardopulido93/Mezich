function [ m,b ] = BestFit( x,y )
N = length(x);
A = 0;
B = 0;
C = 0;
D = 0;
for i = 1:N
   A = A + x(i);
   B = B + y(i);
   C = C + x(i)*y(i);
   D = D + x(i)^2;
end
m = (A*B - N*C)/(A^2 - N*D);
b = (A*C - B*D)/(A^2 - N*D);
end

