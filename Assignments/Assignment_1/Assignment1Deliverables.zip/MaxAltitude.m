function [ Max_h ] = MaxAltitude( R,W_Payload,W_Balloon,MW )
% Calculate total weight
W_Total = TotalWeight( R,W_Payload,W_Balloon,MW );
W_air = W_Total;

h = 0;

while W_Total <= W_air
    h = h + 10; % Altitude (m)
    
    % Calculate air weight
    rho_air = AirDensity( h );
    W_air = AirWeight( rho_air,R );
end

Max_h = h;
end

