% Author: Andrew Mezich
% Created: 01/23/17
% Assignment 1: Problem 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all; clc;

profile on

theta = input('Please enter desired launch angle (degrees): ');
V = input('Please enter desired launch speed (m/s): ');

Trajectory( theta, V )

profile viewer