% Author: Andrew Mezich
% Created: 01/23/17
% Assignment 1: Problem 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all; clc;

x = [-3 12.1 20 0 8 3.7 -5.6 0.5 5.8 10];
y = [-11.06 58.95 109.73 3.15 44.83 21.29 -27.29 5.11 34.01 43.25];

[m,b] = BestFit(x,y);

fprintf('Test data results: \n')
fprintf('m = %f\n',m)
fprintf('b = %f\n\n',b)

alpha = [-5 -2 0 2 3 5 7 10 14];
Cl = [-0.008 -0.003 0.001 0.005 0.007 0.006 0.009 0.017 0.019];

[m,b] = BestFit(alpha,Cl);

y = m*alpha + b;

plot(alpha,Cl,'*',alpha,y)
title('Best Fit line for F-117 Nighthawk data')
xlabel('Alpha')
ylabel('C_l')

legend('Data points','Best fit line','Location','Northwest')
fprintf('F-117 Nighthawk data results: \n')
fprintf('m = %f\n',m)
fprintf('b = %f\n',b)

