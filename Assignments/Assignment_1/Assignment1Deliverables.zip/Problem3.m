% Author: Andrew Mezich
% Created: 01/23/17
% Assignment 1: Problem 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all; close all; clc;

%profile on

% Define known values
R = 3.0; % Balloon radius (m)
W_Payload = 5; % Payload weight (kg)
W_Balloon = 0.6; % Empty weight (kg)
MW = 4.02; % Molecular weight of lifting gas (Helium)

% Find maximum balloon altitude
Max_h = MaxAltitude( R,W_Payload,W_Balloon,MW );

fprintf('Max altitude = %f meters\n',Max_h)
%profile viewer