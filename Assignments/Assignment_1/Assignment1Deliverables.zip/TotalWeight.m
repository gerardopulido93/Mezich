function [ W_Total ] = TotalWeight( R,W_Payload,W_Balloon,MW )
    rho_air_SL = 1.225; % Density of air at Sea Level (kg/m^3)
    
    W_Gas = ((4*pi*rho_air_SL*R^3)/3)*(MW/28.966);
    
    W_Total = W_Gas + W_Payload + W_Balloon;
end

