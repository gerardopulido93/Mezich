function [  ] = Trajectory( theta, V )
g = -9.81; % m/s^2
x(1) = 0;
y(1) = 0;
t(1) = 0;
dt = 0.01;
i = 1;
while y >= 0
    i = i + 1;
    t(i) = t(i-1) + dt;
    x(i) = V*cosd(theta)*t(i);
    y(i) = 0.5*g*t(i)^2 + V*sind(theta)*t(i);
end

if y(i) < 0
    y(i) = 0;
end

plot(t,x,t,y)
title('Trajectory of projectile')
xlabel('Time (s)')
ylabel('Displacement (m)')
grid on; grid minor;

legend('Horizontal Displacement','Vertical Displacement','Location','North')
end

