
function varargout = AssignmentGUI(varargin)

% ASSIGNMENTGUI MATLAB code for AssignmentGUI.fig
%      ASSIGNMENTGUI, by itself, creates a new ASSIGNMENTGUI or raises the existing
%      singleton*.
%
%      H = ASSIGNMENTGUI returns the handle to a new ASSIGNMENTGUI or the handle to
%      the existing singleton*.
%
%      ASSIGNMENTGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ASSIGNMENTGUI.M with the given input arguments.
%
%      ASSIGNMENTGUI('Property','Value',...) creates a new ASSIGNMENTGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before AssignmentGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to AssignmentGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help AssignmentGUI

% Last Modified by GUIDE v2.5 14-Feb-2017 21:52:57

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @AssignmentGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @AssignmentGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before AssignmentGUI is made visible.
function AssignmentGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to AssignmentGUI (see VARARGIN)

%% ADDED Code

% Set initial inputs
% handles.PRNinput = 22;
% handles.samplingInput = 40960000;
% handles.intermediateInput = 0;
% handles.msecDataInput = 100;

handles.PRNinput = 22;
handles.samplingInput = 4096000;
handles.intermediateInput = 0;
handles.msecDataInput = 100;

% axes(handles.coorelationResults);
% axes(handles.promptI);
% axes(handles.promptQ);
% axes(handles.trackedCode);
% axes(handles.trackedIntermediate);
% axes(handles.directI);
% axes(handles.directQ);
% axes(handles.reflectI);
% axes(handles.reflectQ);
% axes(handles.reflectRatio);
% axes(handles.reflectComposite);





%%
% Choose default command line output for AssignmentGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes AssignmentGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = AssignmentGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in startButton.
function startButton_Callback(hObject, eventdata, handles)
% hObject    handle to startButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
corrplot(handles)


function msecAvgInput_Callback(hObject, eventdata, handles)
% hObject    handle to msecAvgInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.msecAvgInput = str2double(get(hObject,'String'));
guidata(hObject,handles);
% Hints: get(hObject,'String') returns contents of msecAvgInput as text
%        str2double(get(hObject,'String')) returns contents of msecAvgInput as a double


% --- Executes during object creation, after setting all properties.
function msecAvgInput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msecAvgInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function PRNinput_Callback(hObject, eventdata, handles)
% hObject    handle to PRNinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% determine selecte data set
str = get(hObject,'String');
val = get(hObject,'Value');
handles.PRNinput = str2double(str{val});
guidata(hObject,handles);

% set current data to the selected data

% Hints: get(hObject,'String') returns contents of PRNinput as text
%        str2double(get(hObject,'String')) returns contents of PRNinput as a double

% --- Executes during object creation, after setting all properties.
function PRNinput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PRNinput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function samplingInput_Callback(hObject, eventdata, handles)
% hObject    handle to samplingInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.samplingInput = str2double(get(hObject,'String'));
guidata(hObject,handles);
% Hints: get(hObject,'String') returns contents of samplingInput as text
%        str2double(get(hObject,'String')) returns contents of samplingInput as a double

% --- Executes during object creation, after setting all properties.
function samplingInput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to samplingInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function intermediateInput_Callback(hObject, eventdata, handles)
% hObject    handle to intermediateInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.intermediateInput = str2double(get(hObject,'String'));
guidata(hObject,handles);
% Hints: get(hObject,'String') returns contents of intermediateInput as text
%        str2double(get(hObject,'String')) returns contents of intermediateInput as a double


% --- Executes during object creation, after setting all properties.
function intermediateInput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to intermediateInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function msecDataInput_Callback(hObject, eventdata, handles)
% hObject    handle to msecDataInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.msecDataInput = str2double(get(hObject,'String'));
guidata(hObject,handles);
% Hints: get(hObject,'String') returns contents of msecDataInput as text
%        str2double(get(hObject,'String')) returns contents of msecDataInput as a double

% --- Executes during object creation, after setting all properties.
function msecDataInput_CreateFcn(hObject, eventdata, handles)
% hObject    handle to msecDataInput (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in startProcessing.
function startProcessing_Callback(hObject, eventdata, handles)
% hObject    handle to startProcessing (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq] = ...
    findandtrack(handles.PRNinput, handles.samplingInput, handles.intermediateInput, handles.msecDataInput);
plotresults(e_i,e_q,p_i,p_q,l_i,l_q,carrierfq,codefq,handles);
